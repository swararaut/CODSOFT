import random

responses = {
    "hello": ["Hi there!", "Hello!", "Hey!"],
    "how are you": ["I'm just a computer program, so I don't have feelings, but I'm here to help!",
                    "I'm doing well, thanks for asking."],
    "goodbye": ["Goodbye!", "See you later!", "Have a great day!"],
    "what is your name?": ["hii, I am Chatbot."],
    "can you tell me study tips for competitive exams": ["Create a Study Schedule ","SetClearGoals ",
    "practiceRegularly","Take Short Break"]}


def get_response(user_input):
    user_input = user_input.lower()
    for key in responses:
        if key in user_input:
            return random.choice(responses[key])
    return "I'm sorry, I don't understand that."


print("Chatbot: Hello! How can I help you today? (type 'exit' to end)")

while True:
    user_input = input("You: ")
    if user_input.lower() == "exit":
        print("Chatbot: Goodbye!")
        break
    response = get_response(user_input)
    print("Chatbot:", response)
