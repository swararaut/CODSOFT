# image-captioning-keras-resnet
run 
<br>

<h1> first </h1>
1] app.py for interactive gui but before running this you need model weights and vocab.npy which you can get by running .ipynb file or kaggle notebook

kaggle notebook : https://www.kaggle.com/programminghut/imagecaptioning

<h1> second </h1>
2] non_interative.py for cli predictions.


